# Dimostratore 3DCP

Dimostratore interattivo per la piattaforma 3DCP - stampa 3D robotica in edilizia.
